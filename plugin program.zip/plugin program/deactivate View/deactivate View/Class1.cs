﻿// Deactive of Views
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk.Messages;

namespace deactivate_View
{
    public class Class1:IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory servicefactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));

            IOrganizationService service = servicefactory.CreateOrganizationService(context.UserId);

        string fetchxml=@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                          <entity name='savedquery'>
                            <attribute name='name' />
                            <attribute name='description' />
                            <attribute name='savedqueryid' />
                            <attribute name='statuscode' />
                            <attribute name='statecode' />
                            <order attribute='name' descending='false' />
                            <filter type='and'>
                              <condition attribute='name' operator='eq' value='Closed Opportunities in Current Fiscal Year' />
                            </filter>
                          </entity>
                        </fetch>";

        EntityCollection col=service.RetrieveMultiple(new FetchExpression(fetchxml));

            if (col.Entities.Count>0)
	        {
		      foreach (Entity item in col.Entities)
	           {
		        Guid id=item.GetAttributeValue<Guid>("savedqueryid");

                    SetStateRequest ssreq = new SetStateRequest
                 {
                    EntityMoniker = new EntityReference("savedquery", id),
                    State = new OptionSetValue(1),
                    Status = new OptionSetValue(2)
                 };
                  service.Execute(ssreq);
	           }
	        }
        }
    }
}
