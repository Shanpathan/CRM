﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Client;

namespace Views
{
    public class Class1:IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

                IOrganizationServiceFactory servicefactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
                IOrganizationService service = servicefactory.CreateOrganizationService(context.UserId);

                ITracingService traceingservice = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            System.String layoutXml =@"<grid name='resultset' object='3' jump='name' select='1'   preview='1' icon='1'>
                                        <row name='result' id='opportunityid'>
                                        <cell name='name' width='150' /> 
                                        <cell name='customerid' width='150' /> 
                                        <cell name='estimatedclosedate' width='150' /> 
                                        <cell name='estimatedvalue' width='150' /> 
                                        <cell name='closeprobability' width='150' /> 
                                        <cell name='opportunityratingcode' width='150' /> 
                                        <cell name='opportunitycustomeridcontactcontactid.emailaddress1' 
                                            width='150' disableSorting='1' /> 
                                        </row>
                                    </grid>";

            System.String fetchXml =@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                    <entity name='opportunity'>
                                    <order attribute='estimatedvalue' descending='false' /> 
                                    <filter type='and'>
                                        <condition attribute='statecode' operator='eq' 
                                        value='0' /> 
                                    </filter>
                                    <attribute name='name' /> 
                                    <attribute name='estimatedvalue' /> 
                                    <attribute name='estimatedclosedate' /> 
                                    <attribute name='customerid' /> 
                                    <attribute name='opportunityratingcode' /> 
                                    <attribute name='closeprobability' /> 
                                    <link-entity alias='opportunitycustomeridcontactcontactid' 
                                        name='contact' from='contactid' to='customerid' 
                                        link-type='outer' visible='false'>
                                        <attribute name='emailaddress1' /> 
                                    </link-entity>
                                    <attribute name='opportunityid' /> 
                                    </entity>
                                </fetch>";

            
            Entity savedquery = new Entity("savedquery");
            savedquery.Attributes["name"] = "New Public View";
            savedquery.Attributes["description"] = "A Saved Query created in code";
            savedquery.Attributes["returnedtypecode"] = "opportunity";
            savedquery.Attributes["fetchxml"] = fetchXml;
            savedquery.Attributes["layoutxml"] = layoutXml;
            savedquery.Attributes["querytype"] = 0;
            Guid id = service.Create(savedquery);
        }
    }
}
