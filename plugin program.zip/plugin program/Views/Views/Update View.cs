﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk;

namespace Views
{
   public class Update_View:IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory servicefactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = servicefactory.CreateOrganizationService(context.UserId);


            QueryExpression query = new QueryExpression("savedquery");
            query.ColumnSet = new ColumnSet(true);
            query.Criteria.AddCondition("name", ConditionOperator.Equal, "Public View");
            EntityCollection col = service.RetrieveMultiple(query);
            if (col.Entities.Count > 0)
            {
                foreach (Entity item in col.Entities)
                {
                    string name = item.GetAttributeValue<string>("name");
                    //throw new InvalidPluginExecutionException(name);
                    item.Attributes["name"] = "My Public View";
                    var updateRequest = new UpdateRequest() { Target = item };
                    var updateResponse = (UpdateResponse)service.Execute(updateRequest);
                    break;
                }
            }
        }
    }
}
