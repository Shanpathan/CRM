﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Crm.Sdk;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;


namespace Views
{
  public class Edit_Columns:IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            IOrganizationServiceFactory servicefactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = servicefactory.CreateOrganizationService(context.UserId);

            QueryExpression query = new QueryExpression("savedquery");
            query.ColumnSet = new ColumnSet(true);
            query.Criteria.AddCondition("name", ConditionOperator.Equal, "Public View");
            EntityCollection col = service.RetrieveMultiple(query);
            if (col.Entities.Count>0)
            {
                foreach (Entity item in col.Entities)
                {
                    string name = item.GetAttributeValue<string>("name");
                    //throw new InvalidPluginExecutionException(name);
//                    System.String layoutXml = @"<grid name='resultset' object='3' jump='name' select='1'   preview='1' icon='1'>
//                                        <row name='result' id='opportunityid'>
//                                        <cell name='name' width='150' /> 
//                                        <cell name='customerid' width='150' />
//                                        <cell name='opportunityratingcode' width='150' /> 
//                                        <cell name='opportunitycustomeridcontactcontactid.emailaddress1' 
//                                            width='150' disableSorting='1' /> 
//                                        </row>
//                                    </grid>";


//                    item.Attributes["layoutxml"] = layoutXml;
                   // item.Attributes["name"] = "Public view New";
                    
                    service.Delete(item.LogicalName,item.Id);
                    break;
                }
            }
           
        }
    }
}
