﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;

namespace On_create_of_case_notes
{
   public class Class1:CodeActivity
    {
       [Input("Oldcase")]
       [ReferenceTarget("incident")]
       public InArgument<EntityReference> oldcase { get; set; }

       protected override void Execute(CodeActivityContext Executioncontext)
        {
            IWorkflowContext context = Executioncontext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory servicefactory = Executioncontext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = servicefactory.CreateOrganizationService(context.UserId);

            var old = oldcase.Get<EntityReference>(Executioncontext);
            QueryExpression query = new QueryExpression("annotation");
            query.ColumnSet = new ColumnSet(true);
            query.Criteria.AddCondition("objectid", ConditionOperator.Equal, old.Id);

            EntityCollection col = service.RetrieveMultiple(query);


            if (col.Entities.Count > 0)
            {

                foreach (Entity item in col.Entities)
                {
                    Entity Note = new Entity("annotation");
                    if (item.Attributes.Contains("subject"))
                    {
                        Note.Attributes["subject"] = item.GetAttributeValue<string>("subject");
                    }
                    if (item.Attributes.Contains("notetext"))
                    {
                        Note.Attributes["notetext"] = item.GetAttributeValue<string>("notetext");
                    }
                    if (item.Attributes.Contains("filename"))
                    {
                        string strMessage = item.GetAttributeValue<string>("documentbody");
                        Note.Attributes["documentbody"] = strMessage;
                        Note.Attributes["filename"] = item.GetAttributeValue<string>("filename");
                    }
                    if (item.Attributes.Contains("mimetype"))
                    {
                        Note.Attributes["mimetype"] = item.GetAttributeValue<string>("mimetype");
                    }                             
                    Note.Attributes["objectid"] = new EntityReference("incident", context.PrimaryEntityId);
                    Note.Attributes["objecttypecode"] = "incident"; ////Object Type (Entity Type) Annotation is for which Entity
                    service.Create(Note);

                }
            }

            QueryExpression querytask = new QueryExpression("task");
            querytask.ColumnSet = new ColumnSet(true);
            querytask.Criteria.AddCondition("regardingobjectid", ConditionOperator.Equal, old.Id);

            EntityCollection taskresult = service.RetrieveMultiple(querytask);
            if (taskresult.Entities.Count > 0)
            {
                foreach (Entity taskitem in taskresult.Entities)
                {
                    Entity Task = new Entity("task");

                    if (taskitem.Attributes.Contains("subject"))
                    {
                        Task.Attributes["subject"] = taskitem.GetAttributeValue<string>("subject");
                    }
                    if (taskitem.Attributes.Contains("prioritycode"))
                    {
                        int priority = (taskitem.GetAttributeValue<OptionSetValue>("prioritycode")).Value;
                        Task.Attributes["prioritycode"] = new OptionSetValue(priority);
                    }
                    if (taskitem.Attributes.Contains("scheduledend"))
                    {
                        Task.Attributes["scheduledend"] = taskitem.GetAttributeValue<DateTime>("scheduledend");
                    }
                    if (taskitem.Attributes.Contains("description"))
                    {
                        Task.Attributes["description"] = taskitem.GetAttributeValue<string>("description");
                    }
                    if (taskitem.Attributes.Contains("regardingobjectid"))
                    {
                        Task.Attributes["regardingobjectid"] = new EntityReference(context.PrimaryEntityName, context.PrimaryEntityId);
                    }
                    if (taskitem.Attributes.Contains("actualdurationminutes"))
                    {
                        Task.Attributes["actualdurationminutes"] = taskitem.GetAttributeValue<int>("actualdurationminutes");
                    }                 

                   Guid  taskid= service.Create(Task);


                   int activitystatus = (taskitem.GetAttributeValue<OptionSetValue>("statecode")).Value;
                   int statusreason = (taskitem.GetAttributeValue<OptionSetValue>("statuscode")).Value;  
                   SetStateRequest request = new SetStateRequest
                   {
                       EntityMoniker = new EntityReference("task", taskid),
                       State = new OptionSetValue(activitystatus),
                       Status = new OptionSetValue(statusreason)
                   };

                   service.Execute(request);

                   
                    
                }
            }


            QueryExpression queryphonecall = new QueryExpression("phonecall");
            queryphonecall.ColumnSet = new ColumnSet(true);
            queryphonecall.Criteria.AddCondition("regardingobjectid", ConditionOperator.Equal, old.Id);
            EntityCollection phonecallresult = service.RetrieveMultiple(queryphonecall);
            if (phonecallresult.Entities.Count > 0)
            {
                foreach (Entity phonecallitem in phonecallresult.Entities)
                {
                    Entity Phonecall = new Entity("phonecall");
                    if (phonecallitem.Attributes.Contains("subject"))
                    {
                        Phonecall.Attributes["subject"] = phonecallitem.GetAttributeValue<string>("subject");
                    }
                    if (phonecallitem.Attributes.Contains("prioritycode"))
                    {
                        int priority = (phonecallitem.GetAttributeValue<OptionSetValue>("prioritycode")).Value;
                        Phonecall.Attributes["prioritycode"] = new OptionSetValue(priority);
                    }
                    if (phonecallitem.Attributes.Contains("scheduledend"))
                    {
                        Phonecall.Attributes["scheduledend"] = phonecallitem.GetAttributeValue<DateTime>("scheduledend");
                    }
                    if (phonecallitem.Attributes.Contains("regardingobjectid"))
                    {
                        Phonecall.Attributes["regardingobjectid"] = new EntityReference(context.PrimaryEntityName, context.PrimaryEntityId);
                    }

                    if (phonecallitem.Attributes.Contains("phonenumber"))
                    {
                        Phonecall.Attributes["phonenumber"] = phonecallitem.GetAttributeValue<string>("phonenumber");
                    }
                    if (phonecallitem.Attributes.Contains("description"))
                    {
                        Phonecall.Attributes["description"] = phonecallitem.GetAttributeValue<string>("description");
                    }
                    if (phonecallitem.Attributes.Contains("directioncode"))
                    {
                        Phonecall.Attributes["directioncode"] = phonecallitem.GetAttributeValue<bool>("directioncode");
                    }
                    if (phonecallitem.Attributes.Contains("actualdurationminutes"))
                    {
                        Phonecall.Attributes["actualdurationminutes"] = phonecallitem.GetAttributeValue<int>("actualdurationminutes");
                    }

                    EntityCollection phonecallfrom = phonecallitem.GetAttributeValue<EntityCollection>("from");
                    foreach (Entity item2 in phonecallfrom.Entities)
                    {
                        Entity from = new Entity("activityparty");
                        from["partyid"] = item2.GetAttributeValue<EntityReference>("partyid");
                        Phonecall["from"] = new Entity[] { from };
                    }

                    EntityCollection phonecallto = phonecallitem.GetAttributeValue<EntityCollection>("to");

                    EntityCollection collectionto = new EntityCollection();

                    foreach (Entity item3 in phonecallto.Entities)
                    {
                        Entity to = new Entity("activityparty");
                        to["partyid"] = item3.GetAttributeValue<EntityReference>("partyid");
                        collectionto.Entities.Add(to);
                    }
                    Phonecall["to"] = collectionto;

                   Guid phonecallid=service.Create(Phonecall);

                   int activitystatus = (phonecallitem.GetAttributeValue<OptionSetValue>("statecode")).Value;
                   int statusreason = (phonecallitem.GetAttributeValue<OptionSetValue>("statuscode")).Value;
                    SetStateRequest request = new SetStateRequest
                    {
                        EntityMoniker = new EntityReference("phonecall", phonecallid),
                        State = new OptionSetValue(activitystatus),
                        Status = new OptionSetValue(statusreason)
                    };

                    service.Execute(request);
                }
            }


            QueryExpression queryappointment = new QueryExpression("appointment");
            queryappointment.ColumnSet = new ColumnSet(true);
            queryappointment.Criteria.AddCondition("regardingobjectid", ConditionOperator.Equal, old.Id);
            EntityCollection appointementresult = service.RetrieveMultiple(queryappointment);
            if (appointementresult.Entities.Count > 0)
            {
                foreach (Entity appointementitem in appointementresult.Entities)
                {
                    Entity Appointement = new Entity("appointment");

                    if (appointementitem.Attributes.Contains("subject"))
                    {
                        Appointement.Attributes["subject"] = appointementitem.GetAttributeValue<string>("subject");
                    }
                    if (appointementitem.Attributes.Contains("location"))
                    {
                        Appointement.Attributes["location"] = appointementitem.GetAttributeValue<string>("location");
                    }
                    if (appointementitem.Attributes.Contains("actualdurationminutes"))
                    {
                        Appointement.Attributes["actualdurationminutes"] = appointementitem.GetAttributeValue<int>("actualdurationminutes");
                    }
                    if (appointementitem.Attributes.Contains("prioritycode"))
                    {
                        int priority = (appointementitem.GetAttributeValue<OptionSetValue>("prioritycode")).Value;
                        Appointement.Attributes["prioritycode"] = new OptionSetValue(priority);
                    }
                    if (appointementitem.Attributes.Contains("regardingobjectid"))
                    {
                        Appointement.Attributes["regardingobjectid"] = new EntityReference(context.PrimaryEntityName, context.PrimaryEntityId);
                    }
                    if (appointementitem.Attributes.Contains("isalldayevent"))
                    {
                        Appointement.Attributes["isalldayevent"] = appointementitem.GetAttributeValue<bool>("isalldayevent");
                    }
                    if (appointementitem.Attributes.Contains("scheduledstart"))
                    {
                        Appointement.Attributes["scheduledstart"] = appointementitem.GetAttributeValue<DateTime>("scheduledstart");
                    }
                    if (appointementitem.Attributes.Contains("scheduledend"))
                    {
                        Appointement.Attributes["scheduledend"] = appointementitem.GetAttributeValue<DateTime>("scheduledend");
                    }
                    if (appointementitem.Attributes.Contains("description"))
                    {
                        Appointement.Attributes["description"] = appointementitem.GetAttributeValue<string>("description");
                    }

                    EntityCollection RequiredAttendees = appointementitem.GetAttributeValue<EntityCollection>("requiredattendees");
                    if (RequiredAttendees != null)
                    {
                        EntityCollection collectionrequired = new EntityCollection();
                        foreach (Entity item4 in RequiredAttendees.Entities)
                        {
                            Entity to = new Entity("activityparty");
                            to["partyid"] = item4.GetAttributeValue<EntityReference>("partyid");
                            collectionrequired.Entities.Add(to);
                        }
                        Appointement["requiredattendees"] = collectionrequired;
                    }

                    EntityCollection OptionalAttendees = appointementitem.GetAttributeValue<EntityCollection>("optionalattendees");
                    if (OptionalAttendees != null)
                    {
                        EntityCollection collectionoptional = new EntityCollection();
                        foreach (Entity item5 in OptionalAttendees.Entities)
                        {
                            Entity to = new Entity("activityparty");
                            to["partyid"] = item5.GetAttributeValue<EntityReference>("partyid");
                            collectionoptional.Entities.Add(to);
                        }
                        Appointement["optionalattendees"] = collectionoptional;
                    }

                 Guid appid=service.Create(Appointement);

                 int activitystatus = (appointementitem.GetAttributeValue<OptionSetValue>("statecode")).Value;
                 int statusreason = (appointementitem.GetAttributeValue<OptionSetValue>("statuscode")).Value;
                    SetStateRequest request = new SetStateRequest
                    {
                        EntityMoniker = new EntityReference("appointment", appid),
                        State = new OptionSetValue(activitystatus),
                        Status = new OptionSetValue(statusreason)
                    };

                    service.Execute(request);

                }
            }

            QueryExpression queryemail = new QueryExpression("email");
            queryemail.ColumnSet = new ColumnSet(true);
            queryemail.Criteria.AddCondition("regardingobjectid", ConditionOperator.Equal, old.Id);
            EntityCollection emailresult = service.RetrieveMultiple(queryemail);
            if (emailresult.Entities.Count > 0)
            {
                foreach (Entity emailitem in emailresult.Entities)
                {
                    Entity Email = new Entity("email");

                    if (emailitem.Attributes.Contains("subject"))
                    {
                        Email.Attributes["subject"] = emailitem.GetAttributeValue<string>("subject");
                    }
                    if (emailitem.Attributes.Contains("description"))
                    {
                        Email.Attributes["description"] = emailitem.GetAttributeValue<string>("description");
                    }
                    if (emailitem.Attributes.Contains("prioritycode"))
                    {
                        int priority = (emailitem.GetAttributeValue<OptionSetValue>("prioritycode")).Value;
                        Email.Attributes["prioritycode"] = new OptionSetValue(priority);
                    }
                    if (emailitem.Attributes.Contains("regardingobjectid"))
                    {
                        Email.Attributes["regardingobjectid"] = new EntityReference(context.PrimaryEntityName, context.PrimaryEntityId);
                    }
                    if (emailitem.Attributes.Contains("actualdurationminutes"))
                    {
                        Email.Attributes["actualdurationminutes"] = emailitem.GetAttributeValue<int>("actualdurationminutes");
                    }
                    if (emailitem.Attributes.Contains("scheduledend"))
                    {
                        Email.Attributes["scheduledend"] = emailitem.GetAttributeValue<DateTime>("scheduledend");
                    }

                    EntityCollection emailfrom = emailitem.GetAttributeValue<EntityCollection>("from");
                    if (emailfrom != null)
                    {
                        foreach (Entity item5 in emailfrom.Entities)
                        {
                            Entity from = new Entity("activityparty");
                            from["partyid"] = item5.GetAttributeValue<EntityReference>("partyid");
                            Email["from"] = new Entity[] { from };
                        }
                    }

                    EntityCollection emailto = emailitem.GetAttributeValue<EntityCollection>("to");
                    if (emailto != null)
                    {
                        EntityCollection collectionto = new EntityCollection();
                        foreach (Entity item6 in emailto.Entities)
                        {
                            Entity to = new Entity("activityparty");
                            to["partyid"] = item6.GetAttributeValue<EntityReference>("partyid");
                            collectionto.Entities.Add(to);
                        }
                        Email["to"] = collectionto;
                    }

                    EntityCollection emailcc = emailitem.GetAttributeValue<EntityCollection>("cc");
                    if (emailcc != null)
                    {
                        EntityCollection collectioncc = new EntityCollection();
                        foreach (Entity item6 in emailcc.Entities)
                        {
                            Entity to = new Entity("activityparty");
                            to["partyid"] = item6.GetAttributeValue<EntityReference>("partyid");
                            collectioncc.Entities.Add(to);
                        }
                        Email["cc"] = collectioncc;
                    }

                    EntityCollection emailbcc = emailitem.GetAttributeValue<EntityCollection>("bcc");
                    if (emailbcc != null)
                    {
                        EntityCollection collectionbcc = new EntityCollection();
                        foreach (Entity item7 in emailbcc.Entities)
                        {
                            Entity to = new Entity("activityparty");
                            to["partyid"] = item7.GetAttributeValue<EntityReference>("partyid");
                            collectionbcc.Entities.Add(to);
                        }
                        Email["bcc"] = collectionbcc;
                    }

                  Guid emailid=service.Create(Email);

                  int activitystatus = (emailitem.GetAttributeValue<OptionSetValue>("statecode")).Value;
                  int statusreason = (emailitem.GetAttributeValue<OptionSetValue>("statuscode")).Value;
                  SetStateRequest request = new SetStateRequest
                  {
                      EntityMoniker = new EntityReference("email", emailid),
                      State = new OptionSetValue(activitystatus),
                      Status = new OptionSetValue(statusreason)
                  };

                  service.Execute(request);
                }
            }


        }
    }
}
